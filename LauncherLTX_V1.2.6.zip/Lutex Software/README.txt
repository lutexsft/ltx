LUTEX SOFTWARE SYSTEMS | 2020 - 2025 | ALL RIGHTS RESERVED. | V1.2.6 PUBLIC

- Oyunu başlatmadan önce .exe dosyasını boş bir klasörde başlatın. Yeni dosyalar oluşabilir.
  Destek: https://launcherltx.rf.gd/home